"""Retry-with-error-feedback orchestration for policy extraction."""
from __future__ import annotations

import logging
from typing import Any

from policy_extractor.client import MessageClient
from policy_extractor.extractor import (
    EXTRACT_POLICY_TOOL,
    build_extraction_messages,
    parse_tool_use,
)
from policy_extractor.records import (
    Endorsement,
    ExtractionOutcome,
    PolicyExtraction,
    PremiumComponent,
    RetryFutileEscalation,
    ValidationError,
)
from policy_extractor.validator import validate_extraction

logger = logging.getLogger(__name__)


DEFAULT_EXTRACTOR_MODEL = "claude-haiku-4-5"


def extract_with_retry(
    *,
    client: MessageClient,
    policy_id: str,
    document_text: str,
    max_retries: int = 3,
    model: str = DEFAULT_EXTRACTOR_MODEL,
    max_tokens: int = 2048,
) -> ExtractionOutcome:
    """Extract one policy with validation-driven retry.

    Returns PolicyExtraction on success, RetryFutileEscalation when the source
    document is missing required information (no retry attempted).
    """
    # TODO: Implement the retry-with-error-feedback loop.
    #
    # State you'll carry across attempts:
    #   prior_attempts: list[dict[str, Any]] = []    # feeds build_extraction_messages
    #   history: list[ValidationError] = []           # records every rejected attempt
    #
    # For attempt_index in range(max_retries + 1):
    #   1. messages, system = build_extraction_messages(document_text, prior_attempts).
    #   2. response = client.create(
    #          model=model, max_tokens=max_tokens, system=system, messages=messages,
    #          tools=[EXTRACT_POLICY_TOOL],
    #          tool_choice={"type": "tool", "name": "extract_policy"},
    #      )
    #      ⚠ tool_choice REQUIRES both "type" AND "name" keys. Passing only
    #      {"name": "..."} silently lets the model decide not to call the tool;
    #      parse_tool_use will then raise because there is no tool_use block.
    #   3. extraction = parse_tool_use(response).
    #   4. error = validate_extraction(extraction).
    #      - error is None → success. Return build_extraction(
    #            policy_id=policy_id, extraction=extraction,
    #            attempt_index=attempt_index, history=history,
    #        ).
    #      - error.category == "missing_source" → return RetryFutileEscalation
    #        immediately. The source doc is missing data; no retry can fix that.
    #      - error.category in {"format", "consistency"} → append the error to
    #        history, append a dict shaped like
    #            {"extraction": extraction,
    #             "error_field": error.field,
    #             "error_category": error.category,
    #             "error_pattern": error.detected_pattern,
    #             "error_message": error.message}
    #        to prior_attempts, and continue the loop.
    #
    # If the loop falls through (all max_retries exhausted on format/consistency),
    # return a RetryFutileEscalation referencing the last error with
    # detected_pattern=f"retries_exhausted__{last_error.detected_pattern}".
    raise NotImplementedError("LO-A — implement extract_with_retry.")


def build_extraction(
    *,
    policy_id: str,
    extraction: dict[str, Any],
    attempt_index: int,
    history: list[ValidationError],
) -> PolicyExtraction:
    """Marshal a validated extraction dict into a PolicyExtraction dataclass record."""
    raw_endorsements = extraction.get("endorsements")
    if raw_endorsements is None:
        endorsements: list[Endorsement] | None = None
    else:
        endorsements = [
            Endorsement(name=e["name"], limit=e.get("limit")) for e in raw_endorsements
        ]

    raw_components = extraction.get("premium_components")
    components: list[PremiumComponent] | None = None
    if raw_components is not None:
        components = [
            PremiumComponent(name=c["name"], amount=c["amount"]) for c in raw_components
        ]

    return PolicyExtraction(
        policy_id=policy_id,
        policy_type=extraction["policy_type"],
        premium_amount=extraction["premium_amount"],
        deductible=extraction["deductible"],
        coverage_limit=extraction["coverage_limit"],
        endorsements=endorsements,
        exclusions=list(extraction.get("exclusions") or []),
        premium_components=components,
        confidence=dict(extraction.get("confidence") or {}),
        retry_count=attempt_index,
        final_attempt_index=attempt_index,
        validation_history=list(history),
    )
