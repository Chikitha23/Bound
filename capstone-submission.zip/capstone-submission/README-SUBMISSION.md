# Evaluation and Observability Capstone: submission package

## Status

- `projects/` holds the three final `solution/` projects, copied unmodified (TODO-free) from the course repo.
- `run_all.sh` reproduces every evidence file (tests, mypy, ruff, end-to-end runs, calibration).
- `reflection-brief.md` and `perturbation-log.md` are the provided templates, not filled in. They need answers taken from your own run output.
- The evidence files (`tests.txt`, `static-checks.txt`, run captures) are NOT included. I could not produce them: the sandbox has no Python 3.11 and no PyPI access.

## To finish

1. On a Python 3.11+ machine, run `bash run_all.sh` (set `ANTHROPIC_API_KEY` for the live policy run, otherwise the offline routing test is captured).
2. Check that every step ends with `[exit 0]`.
3. Add at least one screenshot per system to the matching `screenshots/` folder.
4. Fill in `reflection-brief.md` and `perturbation-log.md` using the captured outputs.
5. Zip this folder and submit.
