#!/usr/bin/env bash
# Reproduces the evidence pack on a machine with Python 3.11+ and PyPI access.
# Usage: bash run_all.sh   (set ANTHROPIC_API_KEY first for the live policy run; optional)
set -uo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PY="${PYTHON:-python3.11}"
FAILS=0

setup() {  # $1 = project dir
  cd "$1" && "$PY" -m venv .venv && .venv/bin/pip install -q -e ".[dev]" || return 1
}
step() {   # $1 = output file, rest = command
  local out="$1"; shift
  echo "+ $*" | tee "$out"
  "$@" 2>&1 | tee -a "$out"
  local rc=${PIPESTATUS[0]}
  echo "[exit $rc]" | tee -a "$out"
  [ "$rc" -eq 0 ] || FAILS=$((FAILS+1))
}

# ---- 01 policy pipeline
cd "$ROOT/projects/policy-pipeline" && setup . || { echo "setup failed: policy"; FAILS=$((FAILS+1)); }
D="$ROOT/01-policy-pipeline"
step "$D/tests.txt"        .venv/bin/pytest tests/ -v
step "$D/static-checks.txt" bash -c '.venv/bin/mypy policy_extractor/ ; .venv/bin/ruff check policy_extractor/ tests/'
if [ -n "${ANTHROPIC_API_KEY:-}" ]; then
  step "$D/pipeline-run.txt" .venv/bin/policy-extractor pipeline data/policies/ --routing-out "$D/routing_decisions.json" --seed 42
else
  echo "ANTHROPIC_API_KEY not set: live pipeline skipped; offline routing test captured instead" | tee "$D/pipeline-run.txt"
  step "$D/pipeline-run.txt" .venv/bin/pytest tests/test_us04_routing.py -v
fi
step "$D/calibration-report.txt" .venv/bin/python "$ROOT/calibration_report.py"

# ---- 02 mortgage extraction
cd "$ROOT/projects/mortgage-extraction" && setup . || { echo "setup failed: mortgage"; FAILS=$((FAILS+1)); }
D="$ROOT/02-mortgage-extraction"
step "$D/tests.txt"        .venv/bin/pytest tests/ -v
step "$D/static-checks.txt" bash -c '.venv/bin/mypy mortgage_extractor/ ; .venv/bin/ruff check mortgage_extractor/ tests/'
step "$D/extract-run.txt"      .venv/bin/mortgage-extract fixtures/documents/appraisal_informal_sqft.txt --mode replay
step "$D/discrepancy-run.txt"  .venv/bin/mortgage-extract fixtures/documents/income_sum_mismatch.txt --mode replay
step "$D/missing-field-run.txt" .venv/bin/mortgage-extract fixtures/documents/income_missing_bonus.txt --mode replay

# ---- 03 supply chain
cd "$ROOT/projects/supply-chain" && setup . || { echo "setup failed: supply"; FAILS=$((FAILS+1)); }
D="$ROOT/03-supply-chain"
step "$D/tests.txt"        .venv/bin/pytest tests/ -q
step "$D/static-checks.txt" bash -c '.venv/bin/mypy supply_chain_risk/ ; .venv/bin/ruff check supply_chain_risk/ tests/'
step "$D/investigation-run.txt" .venv/bin/supply-chain-investigate meridian --offline
step "$D/timeout-run.txt"       .venv/bin/supply-chain-investigate meridian --offline --simulate-timeout

cd "$ROOT" && { echo "PYTHON=$PY"; "$PY" --version; uname -a; } > environment.txt
echo; echo "Done. Failed steps: $FAILS (see [exit N] lines in each evidence file)"
exit "$FAILS"
